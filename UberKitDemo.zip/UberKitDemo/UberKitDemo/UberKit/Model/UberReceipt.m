//
//  UberReceipt.m
//  UberKitDemo
//
//  Created by Sahil Mahajan on 09/07/15.
//  Copyright (c) 2015 Sachin Kesiraju. All rights reserved.
//

#import "UberReceipt.h"

@implementation UberReceipt

@end
